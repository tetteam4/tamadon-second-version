import {createContext, useContext} from "react";
const DispatchContext = createContext();
export default DispatchContext;


