const DesignerMainPage = ({ chartData }) => {
  return <div></div>;
};

export default DesignerMainPage;
