import React, { useState } from 'react'

function Token() {
const {token , setToken}=useState("")

  return (
    <div>
      <h1>Add Token</h1>
    </div>
  );
}

export default Token